/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package crudmvc;

import controlador.Controlador;
import modelo.SqlUsuarios;
import modelo.usuarios;
import vista.Login;
import vista.home;
import vista.inicio;
import vista.registro;

/**
 *
 * @author RAFAEL
 */
public class CRUDMVC {
    
    public static void main(String[] args){
        Login logeo = new Login();
        registro view = new registro();
        home home = new home();
        ;
        inicio inicio = new inicio();
        
        Controlador ctrl = new Controlador( home, inicio,logeo,view);
        ctrl.iniciar();
        inicio.setVisible(true);
    }
}

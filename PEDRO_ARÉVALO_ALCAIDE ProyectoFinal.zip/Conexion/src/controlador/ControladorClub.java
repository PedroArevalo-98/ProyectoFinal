/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.table.DefaultTableModel;
import modelo.JugadoresClub.Club;
import modelo.JugadoresClub.ClubSql;
import modelo.JugadoresClub.Conexion;
import vista.JugadoresClub.interfazClub;

/**
 *
 * @author RAFAEL
 */
public class ControladorClub implements ActionListener,MouseListener{
    
    ClubSql ClubSql = new ClubSql();
    Club club = new Club();
    interfazClub interfaz = new interfazClub();
    DefaultTableModel modelo = new DefaultTableModel();
     
    
    public ControladorClub(interfazClub interfaz){
        this.interfaz=interfaz;
        this.interfaz.txtbuscar.addActionListener(this);
        this.interfaz.tablaClubs.addMouseListener(this);
        
    }
    public enum AccionMVC
    {
        __VER_EQUIPOS,
        __AGREGAR_EQUIPOS,
        __ELIMINAR_EQUIPOS,
        _MODIFICAR_EQUIPOS,
        __BUSCAR_EQUIPOS
    }
    
     public void iniciar()
    {
        // Skin tipo WINDOWS
        try {
            UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
            
            interfaz.setVisible(true);
        } catch (UnsupportedLookAndFeelException ex) {}
          catch (ClassNotFoundException ex) {}
          catch (InstantiationException ex) {}
          catch (IllegalAccessException ex) {}

        //declara una acción y añade un escucha al evento producido por el componente
        this.interfaz.__VER_EQUIPOS.setActionCommand( "__VER_EQUIPOS" );
        this.interfaz.__VER_EQUIPOS.addActionListener(this);
        //declara una acción y añade un escucha al evento producido por el componente
        this.interfaz.__AGREGAR_EQUIPOS.setActionCommand( "__AGREGAR_EQUIPOS" );
        this.interfaz.__AGREGAR_EQUIPOS.addActionListener(this);
        //declara una acción y añade un escucha al evento producido por el componente
        this.interfaz.__ELIMINAR_EQUIPOS.setActionCommand( "__ELIMINAR_EQUIPOS" );
        this.interfaz.__ELIMINAR_EQUIPOS.addActionListener(this);

        //añade e inicia el jtable con un DefaultTableModel vacio
        this.interfaz.tablaClubs.addMouseListener(this);
        this.interfaz.tablaClubs.setModel( new DefaultTableModel() );
        
        //PRUEBA PARA AÑADIR MODIFICAR
        this.interfaz._MODIFICAR_EQUIPOS.setActionCommand("_MODIFICAR_EQUIPOS");
        this.interfaz._MODIFICAR_EQUIPOS.addActionListener(this);
        
        this.interfaz.txtbuscar.setActionCommand( "__BUSCAR_EQUIPOS" );
        this.interfaz.txtbuscar.addActionListener(this);
    }
   
    //cuando clickes en una fila de la tabla sus datos irán automaticamente a los cuadros de texto;
    @Override
    public void mouseClicked(MouseEvent e) {
        if( e.getButton()== 1)//boton izquierdo
        {
            limpiar();
            desbloquear();
             int fila = this.interfaz.tablaClubs.getSelectedRow();
             if (fila > -1){                
                this.interfaz.txtIdEquipo.setText(( this.interfaz.tablaClubs.getModel().getValueAt(fila, 0).toString() ));
                this.interfaz.txtNombreOficial.setText( ( this.interfaz.tablaClubs.getModel().getValueAt(fila, 2).toString() ));
                this.interfaz.txtEstadio.setText( ( this.interfaz.tablaClubs.getModel().getValueAt(fila, 3).toString() ));
                
                try {
                    DefaultTableModel modelo1 = (DefaultTableModel)interfaz.tablaClubs.getModel();
                    java.util.Date date = new SimpleDateFormat("yyyy-MM-dd").parse((String)modelo1.getValueAt(fila, 1));
                    interfaz.dateAñoCreacion.setDate(date);
                } catch (ParseException ex) {
                    Logger.getLogger(ControladorClub.class.getName()).log(Level.SEVERE, null, ex);
                }
              
               
             }
        }
    }
    @Override
    public void actionPerformed(ActionEvent ae) {
     
        switch ( AccionMVC.valueOf( ae.getActionCommand() ) )
        {
            case __BUSCAR_EQUIPOS:
                 
                 listarEquipos(interfaz.tablaClubs);
                 break;
            case __VER_EQUIPOS:
                //obtiene del modelo los registros en un DefaultTableModel y lo asigna en la vista
                this.interfaz.tablaClubs.setModel( this.ClubSql.getClubTabla());
                break;
            case __AGREGAR_EQUIPOS:
                //si hay algún campo vacio te lanza un error
                if(this.interfaz.dateAñoCreacion.getDate()==null  ||this.interfaz.txtEstadio.getText().equals("")||this.interfaz.txtNombreOficial.getText().equals(""))
            { JOptionPane.showMessageDialog(null, "Rellene todos los campos");
            break;
            }else{
                 String fecha1 =this.interfaz.dateAñoCreacion.getCalendar().get(Calendar.YEAR)+"-"+
                        this.interfaz.dateAñoCreacion.getCalendar().get(Calendar.MARCH)+"-"+
                        this.interfaz.dateAñoCreacion.getCalendar().get(Calendar.DAY_OF_MONTH);
              
                Club club = new Club(
                        fecha1,
                        this.interfaz.txtNombreOficial.getText(),
                        this.interfaz.txtEstadio.getText() );
                        
                        
                if ( this.ClubSql.registrar(club)) 
                {
                    this.interfaz.tablaClubs.setModel( this.ClubSql.getClubTabla());
                    JOptionPane.showMessageDialog(interfaz,"Exito: Nuevo registro agregado.");
                    limpiar();
                }
                else //ocurrio un error
                    JOptionPane.showMessageDialog(interfaz,"Error: Los datos son incorrectos.");
                break;
            }
            case __ELIMINAR_EQUIPOS:
                //si hay algún campo vacio te lanza un error
                if(this.interfaz.txtIdEquipo.getText().equals(""))
            { JOptionPane.showMessageDialog(null, "Seleccione un equipo");
            break;
            }else{
                if ( this.ClubSql.EliminarClub(this.interfaz.txtIdEquipo.getText() ) )
                {
                    this.interfaz.tablaClubs.setModel( this.ClubSql.getClubTabla());
                    JOptionPane.showMessageDialog(interfaz,"Exito: Registro eliminado.");
                    limpiar();
                }
            }
                break; 
            case _MODIFICAR_EQUIPOS:
        {
            //si hay algún campo vacio te lanza un error
            if(this.interfaz.dateAñoCreacion.getDate()==null  ||this.interfaz.txtEstadio.getText().equals("")||this.interfaz.txtNombreOficial.getText().equals(""))
            { JOptionPane.showMessageDialog(null, "rellene todos los campos");
            break;
            }else{
            String fecha =this.interfaz.dateAñoCreacion.getCalendar().get(Calendar.YEAR)+"-"+
                        this.interfaz.dateAñoCreacion.getCalendar().get(Calendar.MARCH)+"-"+
                        this.interfaz.dateAñoCreacion.getCalendar().get(Calendar.DAY_OF_MONTH);
            if ( this.ClubSql.Modificar_Club(
                    Integer.parseInt(this.interfaz.txtIdEquipo.getText()),
                    fecha,
                    this.interfaz.txtNombreOficial.getText(),
                    this.interfaz.txtEstadio.getText() ) )
            {
                this.interfaz.tablaClubs.setModel( this.ClubSql.getClubTabla());
                JOptionPane.showMessageDialog(interfaz,"Exito: El registro ha sido modificado.");
                limpiar();
            
            }else{ //ocurrio un error
                JOptionPane.showMessageDialog(interfaz,"Error: Los datos son incorrectos.");
                break;
                
            }
        }}
    }
    
    /**
     * listar busca en la base de datos los campos que sean similares a lo introducido en el cuadro de texto de txtbuscar
     * @param tablaClub 
     */}
       public void listarEquipos(JTable tablaJugadores){
        try {
            String[] titulos = {"Id_Club" , "Año Creación", "Nombre Oficial" , "Estadio"};
            String[] registros = new String[50];
            // compara lo introducido en el cuadro de texto buscar con todo lo que haya en la base de datos
            String sql ="SELECT * FROM Club WHERE id_club LIKE '%" +interfaz.txtbuscar.getText() + "%'" +
                    "OR añoCreacion LIKE '%" +interfaz.txtbuscar.getText() + "%'"
                    + " OR nombre LIKE '%" +interfaz.txtbuscar.getText() + "%'" +
                    " OR estadios LIKE '%" +interfaz.txtbuscar.getText() + "%'";
            DefaultTableModel model = new DefaultTableModel (null, titulos);
            Conexion cc = new Conexion();
            Connection conect = cc.getConexion();
            Statement st = (Statement) conect.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()){
                registros[0]=rs.getString("id_club");
                registros[1]=rs.getString("añoCreacion");
                registros[2]=rs.getString("nombre");
                registros[3]=rs.getString("estadios");
               
                model.addRow(registros);
            }
            interfaz.tablaClubs.setModel(model);
        } catch (SQLException ex) {
            Logger.getLogger(ControladorJugadores.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        
        /**
         * método nos permite limpiar todos los cuadros de texto
         **/
      }  public void limpiar(){
         interfaz.txtIdEquipo.setText(" ");
         interfaz.txtEstadio.setText(" ");
         interfaz.dateAñoCreacion.setDate(null); // revisar
       
         interfaz.txtNombreOficial.setText(" ");
      }
      
      public void desbloquear(){
         
         interfaz.txtEstadio.setEnabled(true);
         interfaz.dateAñoCreacion.setEnabled(true);
     
         interfaz.txtNombreOficial.setEnabled(true);
      }

    @Override
    public void mousePressed(MouseEvent me) {
        
    }

    @Override
    public void mouseReleased(MouseEvent me) {
        
    }

    @Override
    public void mouseEntered(MouseEvent me) {
        
    }

    @Override
    public void mouseExited(MouseEvent me) {
        
    }

   
}

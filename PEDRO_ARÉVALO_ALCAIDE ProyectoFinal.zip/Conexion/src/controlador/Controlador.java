/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import javax.swing.JOptionPane;
import modelo.SqlUsuarios;
import modelo.usuarios;
import vista.Login;
import vista.home;
import vista.inicio;
import vista.registro;

/**
 *
 * @author RAFAEL
 */
//para que pueda escuchar los eventos de algún botón
public class Controlador implements ActionListener{
    

    SqlUsuarios SqlUs = new SqlUsuarios();
    usuarios user = new usuarios();
    Login logeo;
    inicio inicio ;
    registro view ;
    home Home ;
    int tipoUsuario=1;
    
    public Controlador(home home,inicio inicio,Login logeo, registro view){
        
        this.logeo=logeo;
        this.view=view;
        this.inicio=inicio;
        this.Home=home;
       
     
        
    }
       
    public void iniciar(){
        inicio.setTitle("Inicio");
        inicio.setLocationRelativeTo(null);
        this.inicio.btnIngresar.addActionListener(this);
        this.inicio.btnRegistrar.addActionListener(this);
        this.logeo.btnLogeo.addActionListener(this);
        this.view.btnRegistrarse.addActionListener(this);
        this.view.cmboxTipoUsuario.addActionListener(this);
        
        
       
        
    }
  
    
    @Override
    public void actionPerformed(ActionEvent e){
        //botón de registrarse del menú de inicio
        if(e.getSource()== view.btnRegistrarse){
            // como hemos colocado la contraseña como "cuadro de contraseña" no nos devolverá un String
        //nos va a devolver un Char con arreglo, para facilitar la evaluación lo tratamos todo como String
            String pass = new String(view.txtContraseña.getPassword());
            String passCon = new String(view.txtConfirmarContraseña.getPassword());
            
            
           //si hay algún campo vacio te lanza un error
            if(view.txtUsuario.getText().equals("") || view.txtNombre.getText().equals("") || view.txtCorreo.getText().equals("") ||
                    view.txtUsuario.getText().equals("") || pass.equals("") || passCon.equals("")){
                JOptionPane.showMessageDialog(null, "Hay campos vacios, debe llenar todos los campos");
                
            }else{
            //Solo pasa si las dos contraseñas sean iguales
            if(pass.equals(passCon))
        {   //solo pasa si no existe ya ese usuario
            if(SqlUs.existeUsuario(view.txtUsuario.getText())==0){
           
            if(SqlUs.esEmail(view.txtCorreo.getText())){
            user.setUsuario(view.txtUsuario.getText());
            user.setPassword(pass);
            user.setNombre(view.txtNombre.getText());
            user.setCorreo(view.txtCorreo.getText());
            // 1 para administrador, 2 para usuario normal
            user.setId_tipo(tipoUsuario);
            if(tipoUsuario==2){
                user.setNombre_tipo("Administrador");
            }else{
                user.setNombre_tipo("Usuario");
            }
            if(SqlUs.registrar(user)){
                JOptionPane.showMessageDialog(null, "Registro guardado");
                limpiar();
                 view.dispose();
                    
                   new ControladorHome(new home(user)).iniciar();
                  // Home.setVisible(true);
            }else {
                JOptionPane.showMessageDialog(null,"Error al guardar");
                limpiar();
            }
            }else{
                JOptionPane.showMessageDialog(null, "El correo electronico no es valido");
            }
            }else {
                JOptionPane.showMessageDialog(null,"El usuario ya existe");
            }
        }else{
            JOptionPane.showMessageDialog(null, "Las contraseñas no coinciden");
           
        }}
        } if(e.getSource()==logeo.btnLogeo){
            if(logeo.txtUsuario.getText().equals("")||logeo.txtPassword.getText().equals("")){
                JOptionPane.showMessageDialog(null, "rellene todos los campos ");
            }else{
            SqlUsuarios SqlUs = new SqlUsuarios();
            usuarios user = new usuarios();
            String contr = new String (logeo.txtPassword.getPassword());
            //fecha y hora para el registro del último inicio de sesión
             LocalDate hoy = LocalDate.now();
            LocalTime ahora = LocalTime.now();
            LocalDateTime fecha =LocalDateTime.of(hoy, ahora);
            
            //Cuando ni el campo del usuario ni el de la contraseña están vacios 
            if(!logeo.txtUsuario.getText().equals("")&&!contr.equals("")){
             //le enviamos tanto el usuario como la contraseña
                user.setUsuario(logeo.txtUsuario.getText());
                user.setPassword(contr);
                user.setUltima_sesion(fecha.toString());
                
                if(SqlUs.login(user)){
                   
                   
                   //Cuando el usuario entre en su cuenta se cierra tanto el menú de iniciar sesión como el de registrarse
                   new ControladorHome(new home(user)).iniciar();
                   this.logeo.dispose();
                   this.inicio.dispose();
                }else{
                    JOptionPane.showMessageDialog(null, "Datos incorrectos");
                }
            }else{
                JOptionPane.showMessageDialog(null, "Datos no introducidos");
            }
            }
        }if(e.getSource()==inicio.btnIngresar){
           
            

                logeo.setVisible(true);
                
            
        } if(e.getSource()==inicio.btnRegistrar){
           
            
              
               view.setVisible(true);
            }
        //combobox que le permite al usuario la opción de cambiar su rol
        if(e.getSource()== view.cmboxTipoUsuario){
         if(view.cmboxTipoUsuario.getSelectedItem()== "Administrador"){
                String permiso=JOptionPane.showInputDialog("Escriba la contraseña para poder ser administrador:");
                if(permiso!=null){
                if(permiso.equals("1234")){
                    JOptionPane.showMessageDialog(null, "Código aceptado");
                    tipoUsuario=2;
                
                }else{
                    JOptionPane.showMessageDialog(null, "Código erroneo");
                    view.cmboxTipoUsuario.setSelectedIndex(0);
                }
            }else{
                    view.cmboxTipoUsuario.setSelectedIndex(0);
                }
         }
        }
    }
    public void limpiar(){
        view.txtConfirmarContraseña.setText(null);
        view.txtContraseña.setText(null);
        view.txtCorreo.setText(null);
        view.txtNombre.setText(null);
        view.txtUsuario.setText(null);
    }
}

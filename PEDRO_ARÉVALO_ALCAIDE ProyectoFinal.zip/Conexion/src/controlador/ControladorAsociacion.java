/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.table.DefaultTableModel;
import modelo.JugadoresClub.Asociacion;
import modelo.JugadoresClub.AsociacionSQL;
import modelo.JugadoresClub.Conexion;
import vista.JugadoresClub.vistaAsociacion;

/**
 *
 * @author RAFAEL
 */
public class ControladorAsociacion implements ActionListener,MouseListener{
    
    
     AsociacionSQL AsSql = new AsociacionSQL();
    Asociacion As = new Asociacion();
    vistaAsociacion interfaz = new vistaAsociacion();
    DefaultTableModel modelo = new DefaultTableModel();
     
    
    public ControladorAsociacion(vistaAsociacion interfaz){
        this.interfaz=interfaz;
        
        this.interfaz.tablaJugadores.addMouseListener(this);
        
        
    }
    public enum AccionMVC
    {
        __VER_ASOCIACIONES,
        __AGREGAR_ASOCIACIONES,
        __ELIMINAR_ASOCIACIONES,
        __BUSCAR_EQUIPO,
        __BUSCAR_JUGADOR
       
    }
    
     public void iniciar()
    {
        // Skin tipo WINDOWS
        try {
            UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
            
            interfaz.setVisible(true);
        } catch (UnsupportedLookAndFeelException ex) {}
          catch (ClassNotFoundException ex) {}
          catch (InstantiationException ex) {}
          catch (IllegalAccessException ex) {}

        //declara una acción y añade un escucha al evento producido por el componente
        this.interfaz.btnAsociaciones.setActionCommand( "__VER_ASOCIACIONES" );
        this.interfaz.btnAsociaciones.addActionListener(this);
        //declara una acción y añade un escucha al evento producido por el componente
        this.interfaz.btnAgregar.setActionCommand( "__AGREGAR_ASOCIACIONES" );
        this.interfaz.btnAgregar.addActionListener(this);
        //declara una acción y añade un escucha al evento producido por el componente
        this.interfaz.btnEliminar.setActionCommand( "__ELIMINAR_ASOCIACIONES" );
        this.interfaz.btnEliminar.addActionListener(this);
        
        this.interfaz.txtBuscarEquip.setActionCommand( "__BUSCAR_EQUIPO" );
        this.interfaz.txtBuscarEquip.addActionListener(this);
        
        this.interfaz.txtbuscar.setActionCommand( "__BUSCAR_JUGADOR" );
        this.interfaz.txtbuscar.addActionListener(this);

        //añade e inicia el jtable con un DefaultTableModel vacio
        this.interfaz.tablaJugadores.addMouseListener(this);
        this.interfaz.tablaJugadores.setModel( new DefaultTableModel() );
        
        
        //combobox();
        //PRUEBA PARA AÑADIR MODIFICAR
        
    }
   
    //cuando clickes en una fila de la tabla sus datos irán automaticamente a los cuadros de texto;
    @Override
    public void mouseClicked(MouseEvent e) {
        if( e.getButton()== 1)//boton izquierdo
        {
            
            
            
           // DefaultTableModel model2 = new DefaultTableModel (null, titulos);
            
             int fila = this.interfaz.tablaJugadores.getSelectedRow();
            
             if (fila > -1 && interfaz.tablaJugadores.getModel().getColumnCount()==5){                
                this.interfaz.txtIdJugador.setText(( this.interfaz.tablaJugadores.getModel().getValueAt(fila, 1).toString() ));
                this.interfaz.txtIdEquipo.setText(( this.interfaz.tablaJugadores.getModel().getValueAt(fila, 3).toString() ));
                this.interfaz.txtañotemp.setText(( this.interfaz.tablaJugadores.getModel().getValueAt(fila, 4).toString() ));
             }else if(fila >-1 && interfaz.tablaJugadores.getModel().getColumnCount()==6 ){
                 this.interfaz.txtIdJugador.setText(( this.interfaz.tablaJugadores.getModel().getValueAt(fila, 0).toString() ));
             }else if(fila >-1 && interfaz.tablaJugadores.getModel().getColumnCount()==4 ){
                 this.interfaz.txtIdEquipo.setText(( this.interfaz.tablaJugadores.getModel().getValueAt(fila, 0).toString() ));
             }
        }
    }
    @Override
    public void actionPerformed(ActionEvent ae) {
       
        switch ( AccionMVC.valueOf( ae.getActionCommand() ) )
        {
          case __BUSCAR_EQUIPO:
                 
                 listarEquipos(interfaz.tablaJugadores);
                 break;
            case __BUSCAR_JUGADOR:
                 listar(interfaz.tablaJugadores);
                 break;
            case __VER_ASOCIACIONES:
               
                //obtiene del modelo los registros en un DefaultTableModel y lo asigna en la vista
               this.interfaz.tablaJugadores.setModel( this.AsSql.getAsociacionTabla());
                break;
            case __AGREGAR_ASOCIACIONES:
                //añade un nuevo registro
                //si hay algún campo vacio te lanza un error
                if(this.interfaz.txtIdEquipo.getText().equals("")||this.interfaz.txtIdJugador.getText().equals("")){
                    JOptionPane.showMessageDialog(null, "Seleccione un jjugador y un equipo");
                    break;
                }else{
                 int fecha1 =this.interfaz.btnTemporada.getYear();
                       
                 
                Asociacion As = new Asociacion(
                        Integer.valueOf(this.interfaz.txtIdJugador.getText()) ,
                        Integer.valueOf(this.interfaz.txtIdEquipo.getText()),
                         fecha1 );
                        
                if ( this.AsSql.registrarAsociacion(As)) 
                {
                    this.interfaz.tablaJugadores.setModel( this.AsSql.getAsociacionTabla());
                    JOptionPane.showMessageDialog(interfaz,"Exito: Nuevo registro agregado.");
                    limpiar();
                }
                else{ //ocurrio un error
                    JOptionPane.showMessageDialog(interfaz,"Error: Los datos son incorrectos.");}
                break;
                }
            case __ELIMINAR_ASOCIACIONES:
                //si hay algún campo vacio te lanza un error
                 if(this.interfaz.txtIdEquipo.getText().equals("")||this.interfaz.txtIdJugador.getText().equals("")){
                    JOptionPane.showMessageDialog(null, "Seleccione un jugador y un equipo");
                    break;
                }else{
                if ( this.AsSql.EliminarAsociacion(Integer.valueOf(this.interfaz.txtIdJugador.getText()),Integer.valueOf(this.interfaz.txtIdEquipo.getText()) ) )
                {
                    this.interfaz.tablaJugadores.setModel( this.AsSql.getAsociacionTabla());
                    JOptionPane.showMessageDialog(interfaz,"Exito: Registro eliminado.");
                    limpiar();
                }
                break; 
                 }
           
    }
    
    /**
     * listar busca en la base de datos los campos que sean similares a lo introducido en el cuadro de texto de txtbuscar
     * @param tablaJugadores 
     */}
      public void listar(JTable tablaJugadores){
        try {
            String[] titulos = {"Id_jugador" , "Nombre", "Apellido" , "Nacionalidad", "FechaNacimiento", "NIF"};
            String[] registros = new String[50];
            // compara lo introducido en el cuadro de texto buscar con todo lo que haya en la base de datos
            String sql ="SELECT * FROM Jugador WHERE id_jugador LIKE '%" +interfaz.txtbuscar.getText() + "%'" +
                    "OR nombre LIKE '%" +interfaz.txtbuscar.getText() + "%'"
                    + " OR apellido LIKE '%" +interfaz.txtbuscar.getText() + "%'" +
                    " OR nacionalidad LIKE '%" +interfaz.txtbuscar.getText() + "%'" + " OR NIF LIKE '%" +interfaz.txtbuscar.getText() + "%'";
            DefaultTableModel model = new DefaultTableModel (null, titulos);
            Conexion cc = new Conexion();
            Connection conect = cc.getConexion();
            Statement st = (Statement) conect.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()){
                registros[0]=rs.getString("id_jugador");
                registros[1]=rs.getString("nombre");
                registros[2]=rs.getString("apellido");
                registros[3]=rs.getString("nacionalidad");
                registros[4]=rs.getString("fechaNacimiento");
                registros[5]=rs.getString("NIF");
                model.addRow(registros);
            }
            interfaz.tablaJugadores.setModel(model);
        } catch (SQLException ex) {
            Logger.getLogger(ControladorJugadores.class.getName()).log(Level.SEVERE, null, ex);
        }
        
     
        
        /**
         * método nos permite limpiar todos los cuadros de texto
         **/
      }  public void limpiar(){
         interfaz.txtIdEquipo.setText(" ");
         interfaz.txtIdJugador.setText(" ");
         interfaz.txtBuscarEquip.setText(" ");
         interfaz.txtbuscar.setText(" ");
         interfaz.txtañotemp.setText(" ");
      }
      /**
       * listar busca en la base de datos los campos que sean similares a lo introducido en el cuadro de texto de txtbuscarEquip
       * @param tablaJugadores la tabla de la interfaz de jugadores
       */
      public void listarEquipos(JTable tablaJugadores){
        try {
            String[] titulos = {"Id_Club" , "Año Creación", "Nombre Oficial" , "Estadio"};
            String[] registros = new String[50];
            // compara lo introducido en el cuadro de texto buscar con todo lo que haya en la base de datos
            String sql ="SELECT * FROM Club WHERE id_club LIKE '%" +interfaz.txtBuscarEquip.getText() + "%'" +
                    "OR añoCreacion LIKE '%" +interfaz.txtBuscarEquip.getText() + "%'"
                    + " OR nombre LIKE '%" +interfaz.txtBuscarEquip.getText() + "%'" +
                    " OR estadios LIKE '%" +interfaz.txtBuscarEquip.getText() + "%'";
            DefaultTableModel model = new DefaultTableModel (null, titulos);
            Conexion cc = new Conexion();
            Connection conect = cc.getConexion();
            Statement st = (Statement) conect.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()){
                registros[0]=rs.getString("id_club");
                registros[1]=rs.getString("añoCreacion");
                registros[2]=rs.getString("nombre");
                registros[3]=rs.getString("estadios");
               
                model.addRow(registros);
            }
            interfaz.tablaJugadores.setModel(model);
        } catch (SQLException ex) {
            Logger.getLogger(ControladorJugadores.class.getName()).log(Level.SEVERE, null, ex);
        }
        
       
      } 
      public void desbloquear(){
          interfaz.txtIdEquipo.setEnabled(true);
         interfaz.txtIdJugador.setEnabled(true);
         
      }

    @Override
    public void mousePressed(MouseEvent me) {
        
    }

    @Override
    public void mouseReleased(MouseEvent me) {
        
    }

    @Override
    public void mouseEntered(MouseEvent me) {
        
    }

    @Override
    public void mouseExited(MouseEvent me) {
        
    }
     
}

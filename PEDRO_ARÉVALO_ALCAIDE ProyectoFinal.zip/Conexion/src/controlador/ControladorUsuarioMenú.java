/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.table.DefaultTableModel;
import modelo.JugadoresClub.Asociacion;
import modelo.JugadoresClub.AsociacionSQL;
import modelo.JugadoresClub.ClubSql;
import modelo.JugadoresClub.Conexion;
import modelo.JugadoresClub.JugadorSql;

import vista.JugadoresClub.vistaUsuariosMenú;

/**
 *
 * @author RAFAEL
 */
public class ControladorUsuarioMenú implements ActionListener,MouseListener{
    
    ClubSql ClubSql = new ClubSql();
    JugadorSql JugSql = new JugadorSql();
    AsociacionSQL AsSql = new AsociacionSQL();
    Asociacion As = new Asociacion();
    vistaUsuariosMenú interfaz = new vistaUsuariosMenú();
    DefaultTableModel modelo = new DefaultTableModel();
     
    
    public ControladorUsuarioMenú(vistaUsuariosMenú interfaz){
        this.interfaz=interfaz;
        
        this.interfaz.tablaJugadores.addMouseListener(this);
        
        
    }
    public enum AccionMVC
    {
        __VER_ASOCIACIONES,
        __VER_TJUGADORES,
        __VER_TEQUIPOS,
        __BUSCAR_EQUIPO,
        __BUSCAR_JUGADOR,
        __BUSCAR_ASOC_JUGADOR
       
    }
    
     public void iniciar()
    {
        // Skin tipo WINDOWS
        try {
            UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
            
            interfaz.setVisible(true);
        } catch (UnsupportedLookAndFeelException ex) {}
          catch (ClassNotFoundException ex) {}
          catch (InstantiationException ex) {}
          catch (IllegalAccessException ex) {}

        //declara una acción y añade un escucha al evento producido por el componente
        this.interfaz.btnAsociaciones.setActionCommand( "__VER_ASOCIACIONES" );
        this.interfaz.btnAsociaciones.addActionListener(this);
        //declara una acción y añade un escucha al evento producido por el componente
        this.interfaz.btnVerEq.setActionCommand( "__VER_TEQUIPOS" );
        this.interfaz.btnVerEq.addActionListener(this);
        //declara una acción y añade un escucha al evento producido por el componente
        this.interfaz.btnVerJug.setActionCommand( "__VER_TJUGADORES" );
        this.interfaz.btnVerJug.addActionListener(this);
        
        this.interfaz.txtBuscarEquip.setActionCommand( "__BUSCAR_EQUIPO" );
        this.interfaz.txtBuscarEquip.addActionListener(this);
        
        this.interfaz.txtbuscar.setActionCommand( "__BUSCAR_JUGADOR" );
        this.interfaz.txtbuscar.addActionListener(this);
        
        this.interfaz.btnVerAsociacionesJE.setActionCommand( "__BUSCAR_ASOC_JUGADOR" );
        this.interfaz.btnVerAsociacionesJE.addActionListener(this);

        //añade e inicia el jtable con un DefaultTableModel vacio
        this.interfaz.tablaJugadores.addMouseListener(this);
        this.interfaz.tablaJugadores.setModel( new DefaultTableModel() );
        
        
        //combobox();
        //PRUEBA PARA AÑADIR MODIFICAR
        
    }
   
    //cuando clickes en una fila de la tabla sus datos irán automaticamente a los cuadros de texto;
    @Override
    public void mouseClicked(MouseEvent e) {
        if( e.getButton()== 1)//boton izquierdo
        {
            
            desbloquear();
            
           // DefaultTableModel model2 = new DefaultTableModel (null, titulos);
            
             int fila = this.interfaz.tablaJugadores.getSelectedRow();
           
             if (fila > -1 && interfaz.tablaJugadores.getModel().getColumnCount()==6){   
                 limpiar();
              this.interfaz.txtIdJugador.setText(( this.interfaz.tablaJugadores.getModel().getValueAt(fila, 0).toString() ));
             }else if (fila > -1 && interfaz.tablaJugadores.getModel().getColumnCount()==5){
                 
             }else {
                 limpiar();
                 
                   this.interfaz.txtIdEquipo.setText(( this.interfaz.tablaJugadores.getModel().getValueAt(fila, 0).toString() ));
             }
        }
    }
    @Override
    public void actionPerformed(ActionEvent ae) {
       /* if(ae.getSource()==interfaz.txtbuscar){
        
            listar(interfaz.tablaJugadores);
        }else if(ae.getSource()==interfaz.txtBuscarEquip){
            listarEquipos(interfaz.tablaJugadores);
        }*/
        switch ( AccionMVC.valueOf( ae.getActionCommand() ) )
        {
          case __BUSCAR_EQUIPO:
                 limpiar();
                 listarEquipos(interfaz.tablaJugadores);
                 break;
            case __BUSCAR_JUGADOR:
                limpiar();
                 listar(interfaz.tablaJugadores);
                 break;
            case __VER_ASOCIACIONES:
                limpiar();
                //obtiene del modelo los registros en un DefaultTableModel y lo asigna en la vista
                this.interfaz.tablaJugadores.setModel( this.AsSql.getAsociacionTabla());
                
                break;
            case __VER_TJUGADORES:
             this.interfaz.tablaJugadores.setModel(this.JugSql.getJugadoresTabla());
             limpiar();
                break; 
            case __VER_TEQUIPOS:
             this.interfaz.tablaJugadores.setModel(this.ClubSql.getClubTabla());
             limpiar();
                break;  
            case __BUSCAR_ASOC_JUGADOR:
                  if(this.interfaz.txtIdJugador.getText().equals("") && !this.interfaz.txtIdEquipo.getText().equals("")){
             this.interfaz.tablaJugadores.setModel(this.AsSql.BuscarAsociacionEquipo(Integer.valueOf(this.interfaz.txtIdEquipo.getText())));
                }
                else if(this.interfaz.txtIdJugador.getText().equals("") && this.interfaz.txtIdEquipo.getText().equals("")){
                    
                    JOptionPane.showMessageDialog(null, "Seleccione un Jugador o Equipo");
                   
                }else if(this.interfaz.txtIdEquipo.getText().equals("") && !this.interfaz.txtIdJugador.getText().equals("")){
             this.interfaz.tablaJugadores.setModel(this.AsSql.BuscarAsociacionJugadores(Integer.valueOf(this.interfaz.txtIdJugador.getText())));
                }
                else {
                     JOptionPane.showMessageDialog(null, "Seleccione solo un Jugador o Equipo");
                  
                }
            
              
    }
    
    /**
     * listar busca en la base de datos los campos que sean similares a lo introducido en el cuadro de texto de txtbuscar
     * @param tablaJugadores 
     */}
      public void listar(JTable tablaJugadores){
        try {
            String[] titulos = {"Id_jugador" , "Nombre", "Apellido" , "Nacionalidad", "FechaNacimiento", "NIF"};
            String[] registros = new String[50];
            // compara lo introducido en el cuadro de texto buscar con todo lo que haya en la base de datos
            String sql ="SELECT * FROM Jugador WHERE id_jugador LIKE '%" +interfaz.txtbuscar.getText() + "%'" +
                    "OR nombre LIKE '%" +interfaz.txtbuscar.getText() + "%'"
                    + " OR apellido LIKE '%" +interfaz.txtbuscar.getText() + "%'" +
                    " OR nacionalidad LIKE '%" +interfaz.txtbuscar.getText() + "%'" + " OR NIF LIKE '%" +interfaz.txtbuscar.getText() + "%'";
            DefaultTableModel model = new DefaultTableModel (null, titulos);
            Conexion cc = new Conexion();
            Connection conect = cc.getConexion();
            Statement st = (Statement) conect.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()){
                registros[0]=rs.getString("id_jugador");
                registros[1]=rs.getString("nombre");
                registros[2]=rs.getString("apellido");
                registros[3]=rs.getString("nacionalidad");
                registros[4]=rs.getString("fechaNacimiento");
                registros[5]=rs.getString("NIF");
                model.addRow(registros);
            }
            interfaz.tablaJugadores.setModel(model);
        } catch (SQLException ex) {
            Logger.getLogger(ControladorJugadores.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        /**
         * método nos permite limpiar todos los cuadros de texto
        
        /**
         * método nos permite limpiar todos los cuadros de texto
         **/
      }  public void limpiar(){
         interfaz.txtIdJugador.setText("");
         interfaz.txtIdEquipo.setText("");
        
      }
      public void listarEquipos(JTable tablaJugadores){
        try {
            String[] titulos = {"Id_Club" , "Año Creación", "Nombre Oficial" , "Estadio"};
            String[] registros = new String[50];
            // compara lo introducido en el cuadro de texto buscar con todo lo que haya en la base de datos
            String sql ="SELECT * FROM Club WHERE id_club LIKE '%" +interfaz.txtBuscarEquip.getText() + "%'" +
                    "OR añoCreacion LIKE '%" +interfaz.txtBuscarEquip.getText() + "%'"
                    + " OR nombre LIKE '%" +interfaz.txtBuscarEquip.getText() + "%'" +
                    " OR estadios LIKE '%" +interfaz.txtBuscarEquip.getText() + "%'";
            DefaultTableModel model = new DefaultTableModel (null, titulos);
            Conexion cc = new Conexion();
            Connection conect = cc.getConexion();
            Statement st = (Statement) conect.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()){
                registros[0]=rs.getString("id_club");
                registros[1]=rs.getString("añoCreacion");
                registros[2]=rs.getString("nombre");
                registros[3]=rs.getString("estadios");
               
                model.addRow(registros);
            }
            interfaz.tablaJugadores.setModel(model);
        } catch (SQLException ex) {
            Logger.getLogger(ControladorJugadores.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        /**
         * método nos permite limpiar todos los cuadros de texto
        
        /**
         * método nos permite limpiar todos los cuadros de texto
         **/
      } 
      public void desbloquear(){
          interfaz.txtIdJugador.setEnabled(true);
         interfaz.txtIdEquipo.setEnabled(true);
         
      }

    @Override
    public void mousePressed(MouseEvent me) {
        
    }

    @Override
    public void mouseReleased(MouseEvent me) {
        
    }

    @Override
    public void mouseEntered(MouseEvent me) {
        
    }

    @Override
    public void mouseExited(MouseEvent me) {
        
    }
    
}

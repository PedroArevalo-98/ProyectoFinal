package controlador;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import vista.JugadoresClub.interfazClub;
import vista.JugadoresClub.interfazJugadores;
import vista.JugadoresClub.vistaAsociacion;
import vista.JugadoresClub.vistaUsuariosMenú;
import vista.home;
//se importa modelo e interfaz

/**
 * @author Mouse
 */
public class ControladorHome implements ActionListener,MouseListener{

    /** instancia a nuestra interfaz de usuario*/
    home Home ;
    
  

    
   

    /** Constrcutor de clase
     * @param Home Instancia de clase interfaz
     */
    public ControladorHome( home Home )
    {
        this.Home = Home;
    }

    /** Inicia el skin y las diferentes variables que se utilizan */
    public void iniciar()
    {
        
        //declara una acción y añade un escucha al evento producido por el componente
        Home.setVisible(true);
        this.Home.btnGestionarAso.addActionListener(this);
        this.Home.btnGestionarEqui2.addActionListener(this);
        this.Home.btnGestionarJug.addActionListener(this);
        this.Home.btnVerEquiJug.addActionListener(this);
    }

    //Eventos que suceden por el mouse
    public void mouseClicked(MouseEvent e) {
       
    }

    public void mousePressed(MouseEvent e) {}

    public void mouseReleased(MouseEvent e) {}

    public void mouseEntered(MouseEvent e) {}

    public void mouseExited(MouseEvent e) { }
 
    //Control de eventos de los controles que tienen definido un "ActionCommand"
    public void actionPerformed(ActionEvent e) {

    if(e.getSource()== Home.btnGestionarJug){
            
            new ControladorJugadores(new interfazJugadores()).iniciar();
            
            
            
        }if(e.getSource()== Home.btnGestionarEqui2){
            
            new ControladorClub(new interfazClub()).iniciar();
        }if(e.getSource()== Home.btnGestionarAso){
            
            vistaAsociacion vistaAsociacion = new vistaAsociacion();
            new ControladorAsociacion(vistaAsociacion).iniciar();
        }
        if(e.getSource()== Home.btnVerEquiJug){
            
            vistaUsuariosMenú vistaUsuarioMenu = new vistaUsuariosMenú();
            new ControladorUsuarioMenú(vistaUsuarioMenu).iniciar();
                    
        }
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JOptionPane;
import modelo.JugadoresClub.Conexion;

/**
 *
 * @author RAFAEL
 */
public class SqlUsuarios extends Conexion {
    
    public boolean registrar(usuarios usr){
        
        //insercion a mysql,preparamos la consulta y realizamos la insercion
        PreparedStatement ps=null;
        Connection con = getConexion();
        
        String sql ="INSERT INTO usuarios (usuario , contraseña , nombre , correo , id_tipo) VALUES(?,?,?,?,?)";
        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, usr.getUsuario());
            ps.setString(2, usr.getPassword());
            ps.setString(3, usr.getNombre());
            ps.setString(4, usr.getCorreo());
            ps.setInt(5, usr.getId_tipo());
            ps.execute();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(SqlUsuarios.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        
    }

   /* public boolean registrar(usuarios usr){
        
        int confir=JOptionPane.showConfirmDialog(null, "¿Desea guardar estos datos de usuario?", "PREGUNTA",JOptionPane.YES_NO_OPTION);
        if(confir==JOptionPane.YES_OPTION){
            PreparedStatement ps=null;
            Connection con = getConexion();
            
            try {
                ps=con.prepareStatement("{call INSERTARUSUARIO (?,?,?,?)}");
                  ps.setString(1, usr.getUsuario());
            ps.setString(2, usr.getPassword());
            ps.setString(3, usr.getNombre());
            ps.setString(4, usr.getCorreo());
            ResultSet r=ps.executeQuery();
            String respuesta="";
            while (r.next()){
                respuesta=r.getString(1).toString();
            }
            JOptionPane.showMessageDialog(null, respuesta,"CONFIRMACION",JOptionPane.WARNING_MESSAGE);
            return true;
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Error al registrar", "ERROR", JOptionPane.WARNING_MESSAGE);
                return false;
            }
           
        }
        return false;
      
    }*/ 
    public int existeUsuario(String usuario){
        
        //insercion a mysql,preparamos la consulta y realizamos la insercion
        PreparedStatement ps=null;
        ResultSet rs = null;
        Connection con = getConexion();
        
        String sql ="SELECT count(id_usuario) FROM usuarios WHERE usuario = ? ";
        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, usuario);
            rs=ps.executeQuery();
            
            if(rs.next()){
                return rs.getInt(1);
            }
            return 1;
        } catch (SQLException ex) {
            Logger.getLogger(SqlUsuarios.class.getName()).log(Level.SEVERE, null, ex);
            return 1;
        }
        
    }
    
    public boolean login (usuarios usr){
        
        //insercion a mysql,preparamos la consulta y realizamos la insercion
         
        Connection con = getConexion();
        
         String sql ="SELECT u.id_usuario, u.usuario, u.contraseña, u.nombre, u.id_tipo,t.nombre  FROM usuarios AS u INNER JOIN tipo_usuario AS t ON "
                + "u.id_tipo=t.id WHERE usuario = ? ";
        
        // String sql="SELECT id_usuario, usuario, contraseña, usuarios.nombre, id_tipo, tipo_usuario.nombre  FROM usuarios, tipo_usuario  WHERE usuario = ? AND  usuarios.id_usuario=tipo_usuario.id ";
       
        try {
           PreparedStatement ps = con.prepareStatement(sql);
         ps.setString(1, usr.getUsuario());
           ResultSet rs=ps.executeQuery();
           // JOptionPane.showMessageDialog(null, rs);
            /*if(!rs.next()){
                JOptionPane.showMessageDialog(null, "el resultset está vacio");
            }*/
            if(rs.next()){
                
                if(usr.getPassword().equals(rs.getString(3))){
                    
                    String sqlUpdate = "UPDATE usuarios SET ultima_sesion=? WHERE id_usuario=?";
                    ps=con.prepareStatement(sqlUpdate);
                    ps.setString(1,usr.getUltima_sesion());
                    ps.setInt(2,rs.getInt(1));
                    ps.execute();
                    
                    usr.setId_usuario(rs.getInt(1));
                    usr.setNombre(rs.getString(4));
                    usr.setId_tipo(rs.getInt(5));
                    usr.setNombre_tipo(rs.getString(6));
                    return true;
                }else{
                    return false;
                }
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(SqlUsuarios.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        return false;
        
    }
    
    public boolean esEmail(String correo){
        //el patrón tiene que cumplir una estructura, para confirmar que sea un correo
        Pattern patron = Pattern.compile("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"+ "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$");
     // se encarga se hacer la validación del String con el patrón 
        Matcher mather = patron.matcher(correo);
     return mather.find();
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo.JugadoresClub;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import modelo.SqlUsuarios;
import modelo.usuarios;

/**
 *
 * @author RAFAEL
 */
public class ClubSql extends Conexion{
    
    public boolean registrar(Club club){
        
        //insercion a mysql,preparamos la consulta y realizamos la insercion
        PreparedStatement ps=null;
        Connection con = getConexion();
        
        String sql ="INSERT INTO Club (id_club ,añoCreacion , nombre , estadios) VALUES(?,?,?,?)";
        try {
            ps = con.prepareStatement(sql);
            ps.setInt(1, club.getId_club());
            ps.setString(2, club.getAñoCreacion());
            ps.setString(3, club.getNombreOficial());
            ps.setString(4, club.getEstadio());
           
          
            ps.execute();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(SqlUsuarios.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        
    }
    public DefaultTableModel getClubTabla()
    {
      DefaultTableModel tablemodel = new DefaultTableModel();
      int registros = 0;
      String[] columNames = {"Id_Club","Año Creación","Nombre Oficial","Estadios"};
      //obtenemos la cantidad de registros existentes en la tabla y se almacena en la variable "registros"
      //para formar la matriz de datos
      try{
         PreparedStatement pstm = this.getConexion().prepareStatement( "SELECT count(*) as total FROM Club");
         ResultSet res = pstm.executeQuery();
         res.next();
         registros = res.getInt("total");
         res.close();
      }catch(SQLException e){
         System.err.println( e.getMessage() );
      }
    //se crea una matriz con tantas filas y columnas que necesite
    Object[][] data = new String[registros][6];
      try{
          //realizamos la consulta sql y llenamos los datos en la matriz "Object[][] data"
         PreparedStatement pstm = this.getConexion().prepareStatement("SELECT * FROM Club");
         ResultSet res = pstm.executeQuery();
         int i=0;
         while(res.next()){
                data[i][0] = res.getString( "id_club" );
                data[i][1] = res.getString( "añoCreacion" );
                data[i][2] = res.getString( "nombre" );
                data[i][3] = res.getString( "estadios" );
               
                
            i++;
         }
         res.close();
         //se añade la matriz de datos en el DefaultTableModel
         tablemodel.setDataVector(data, columNames );
         }catch(SQLException e){
            System.err.println( e.getMessage() );
        }
        return tablemodel;
    }
    public boolean EliminarClub( String id )
    {
         boolean res=false;
        //se arma la consulta
        String q = " DELETE FROM Club WHERE  id_club='" + id + "' " ;
        //se ejecuta la consulta
         try {
            PreparedStatement pstm = this.getConexion().prepareStatement(q);
            pstm.execute();
            pstm.close();
            res=true;
         }catch(SQLException e){
            System.err.println( e.getMessage() );
        }
        return res;
    }
    
    public boolean Modificar_Club(int id, String añoCreacion , String nombre,String estadios){
        
        int confirmar = JOptionPane.showConfirmDialog(null, "¿Desea modificar los datos actuales?");
        if(confirmar==JOptionPane.YES_OPTION){
            
            String q = "UPDATE Club SET  añoCreacion=?, nombre=? , estadios=?" +"WHERE id_club=?";
            
            try {
                PreparedStatement pstm = this.getConexion().prepareStatement(q);
                
                
                pstm.setString(1,añoCreacion );
                pstm.setString(2, nombre);
                pstm.setString(3, estadios);
                pstm.setInt(4, id);
                
                pstm.execute();
                pstm.close();
                return true;
                
            } catch (SQLException ex) {
                Logger.getLogger(ClubSql.class.getName()).log(Level.SEVERE, null, ex);
                return false;
            }
        } return false;
        
        
    }
}

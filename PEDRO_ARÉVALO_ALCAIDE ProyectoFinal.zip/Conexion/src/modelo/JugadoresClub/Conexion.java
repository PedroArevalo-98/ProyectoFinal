/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo.JugadoresClub;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author RAFAEL
 */
public class Conexion {
    // variables que nos permiten entrar en la base de datos
    private  String base ;//= "parevalo_LigaFutbol";
    private  String user ;//= "Pedro";
    private  String password;// = "Nervion1**";
    private  String url;// = "jdbc:mysql://parevalo.salesianas.es/"+base;
    private Connection con=null;
    

    //método que genere la conexión a mysql
    public Connection getConexion(){
        try { //si la base de datos está caida puedes usar la local cambiando "parevalo.salesianas.es" por "localhost:3306"
            FileInputStream propFile = new FileInputStream("src\\crudmvc\\ConfConexion.properties");
            Properties p = new Properties(System.getProperties());
            p.load(propFile);
            System.setProperties(p);
            if (System.getProperty("mostrarpropierties").compareTo("si") == 0) {
                System.getProperties().list(System.out);
                 user = System.getProperty("user");
        url = System.getProperty("url");
        password = System.getProperty("password");
            }
        } catch (java.io.FileNotFoundException e) {
            JOptionPane.showMessageDialog(null, "No se encuentra el archivo de configuracion" + e);
            System.exit(-1);
        } catch (java.io.IOException w) {
            JOptionPane.showMessageDialog(null, "Ocurrio algun error de I/O");
            System.exit(-1);
        }
        try {
            Class.forName("com.mysql.jdbc.Driver");
            try {
                con=DriverManager.getConnection(url,user,password);
            } catch (SQLException ex) {
                Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
        }
        return con;
    }
    
    
    
    public static void main(String[] args) {
        // TODO code application logic here
    }
}
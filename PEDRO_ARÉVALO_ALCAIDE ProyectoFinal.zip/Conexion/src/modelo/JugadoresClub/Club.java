/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo.JugadoresClub;

/**
 *
 * @author RAFAEL
 */
public class Club {
    
    private int id_club;
    private String NombreOficial;
    private String añoCreacion;
    private String estadio;

    public Club( String añoCreacion,String NombreOficial, String estadio) {
        this.id_club = 0;
        this.añoCreacion = añoCreacion;
        this.NombreOficial = NombreOficial;
        this.estadio = estadio;
    }
    
    public Club(){
        
    }

    public int getId_club() {
        return id_club;
    }

    public void setId_club(int id_club) {
        this.id_club = id_club;
    }

    public String getNombreOficial() {
        return NombreOficial;
    }

    public void setNombreOficial(String NombreOficial) {
        this.NombreOficial = NombreOficial;
    }

    public String getAñoCreacion() {
        return añoCreacion;
    }

    public void setAñoCreacion(String añoCreacion) {
        this.añoCreacion = añoCreacion;
    }

    public String getEstadio() {
        return estadio;
    }

    public void setEstadio(String estadio) {
        this.estadio = estadio;
    }
    
    
}

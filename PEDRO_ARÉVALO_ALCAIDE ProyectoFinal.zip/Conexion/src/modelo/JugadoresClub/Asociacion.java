/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo.JugadoresClub;

/**
 *
 * @author RAFAEL
 */
public class Asociacion {
    private int id_jugador;
    private int id_club;
    private int Temporada;

    public int getId_jugador() {
        return id_jugador;
    }

    public void setId_jugador(int id_jugador) {
        this.id_jugador = id_jugador;
    }

    public int getId_club() {
        return id_club;
    }

    public void setId_club(int id_club) {
        this.id_club = id_club;
    }

    public int getTemporada() {
        return Temporada;
    }

    public void setTemporada(int Temporada) {
        this.Temporada = Temporada;
    }

    public Asociacion(int id_jugador, int id_club, int Temporada) {
        this.id_jugador = id_jugador;
        this.id_club = id_club;
        this.Temporada = Temporada;
    }
    public Asociacion(){
        
    }
    
}

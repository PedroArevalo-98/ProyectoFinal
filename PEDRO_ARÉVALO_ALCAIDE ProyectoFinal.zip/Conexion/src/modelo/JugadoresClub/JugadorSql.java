/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo.JugadoresClub;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import modelo.SqlUsuarios;
import modelo.usuarios;

/**
 *
 * @author RAFAEL
 */
public class JugadorSql extends Conexion{
    
    public boolean registrar(Jugador jug){
        
        //insercion a mysql,preparamos la consulta y realizamos la insercion
        PreparedStatement ps=null;
        Connection con = getConexion();
        
        String sql ="INSERT INTO Jugador (id_jugador,nombre , apellido , nacionalidad , fechaNacimiento ,NIF ) VALUES(?,?,?,?,?,?)";
        try {
            ps = con.prepareStatement(sql);
            ps.setInt(1, jug.getId_jugador());
            ps.setString(2, jug.getNombre());
            ps.setString(3, jug.getApellido());
            ps.setString(4, jug.getNacionalidad());
            ps.setString(5, jug.getFechaNacimiento());
            ps.setString(6, jug.getNIF());
            ps.execute();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(SqlUsuarios.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        
    }
    public DefaultTableModel getJugadoresTabla()
    {
      DefaultTableModel tablemodel = new DefaultTableModel();
      int registros = 0;
      String[] columNames = {"Id_Jugador","Nombre","Apellido","Nacionalidad","Fecha de Nacimiento","NIF"};
      //obtenemos la cantidad de registros existentes en la tabla y se almacena en la variable "registros"
      //para formar la matriz de datos
      try{
         PreparedStatement pstm = this.getConexion().prepareStatement( "SELECT count(*) as total FROM Jugador");
         ResultSet res = pstm.executeQuery();
         res.next();
         registros = res.getInt("total");
         res.close();
      }catch(SQLException e){
         System.err.println( e.getMessage() );
      }
    //se crea una matriz con tantas filas y columnas que necesite
    Object[][] data = new String[registros][6];
      try{
          //realizamos la consulta sql y llenamos los datos en la matriz "Object[][] data"
         PreparedStatement pstm = this.getConexion().prepareStatement("{call MostrarTJugadores}");
         ResultSet res = pstm.executeQuery();
         int i=0;
         while(res.next()){
                data[i][0] = res.getString( "id_jugador" );
                data[i][1] = res.getString( "nombre" );
                data[i][2] = res.getString( "apellido" );
                data[i][3] = res.getString( "nacionalidad" );
                data[i][4] = res.getString( "fechaNacimiento" );
                data[i][5] = res.getString( "NIF" );
                
            i++;
         }
         res.close();
         //se añade la matriz de datos en el DefaultTableModel
         tablemodel.setDataVector(data, columNames );
         }catch(SQLException e){
            System.err.println( e.getMessage() );
        }
        return tablemodel;
    }
    public boolean EliminarJugador( String id )
    {
         boolean res=false;
        //se arma la consulta
        String q = " DELETE FROM Jugador WHERE  id_jugador='" + id + "' " ;
        //se ejecuta la consulta
         try {
            PreparedStatement pstm = this.getConexion().prepareStatement(q);
            pstm.execute();
            pstm.close();
            res=true;
         }catch(SQLException e){
            System.err.println( e.getMessage() );
        }
        return res;
    }
    
    public boolean Modificar_jugador(int id, String nombre , String apellido,String nacionalidad,String fechaNacimiento, String NIF){
        
        int confirmar = JOptionPane.showConfirmDialog(null, "¿Desea modificar los datos actuales?");
        if(confirmar==JOptionPane.YES_OPTION){
            
            String q = "UPDATE Jugador SET  nombre=?, apellido=? , nacionalidad=? , fechaNacimiento=? , NIF=?" +"WHERE id_jugador=?";
            
            try {
                PreparedStatement pstm = this.getConexion().prepareStatement(q);
                
                
                pstm.setString(1, nombre);
                pstm.setString(2, apellido);
                pstm.setString(3, nacionalidad);
                pstm.setString(4, fechaNacimiento);
                pstm.setString(5, NIF);
                pstm.setInt(6, id);
                
                pstm.execute();
                pstm.close();
                return true;
                
            } catch (SQLException ex) {
                Logger.getLogger(JugadorSql.class.getName()).log(Level.SEVERE, null, ex);
                return false;
            }
        } return false;
        
        
    }
    public static boolean validarNIF(String dni) {

	   
	    return dni.matches("^[0-9]{8}[{Q|W|E|R|T|Y|U|I|O|P|A|S|D|F|G|H|J|K|L|Z|X|C|V|B|N|M]$") ;
	    
	}
}
    


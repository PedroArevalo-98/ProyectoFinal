/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo.JugadoresClub;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import modelo.SqlUsuarios;

/**
 *
 * @author RAFAEL
 */
public class AsociacionSQL extends Conexion{
    
    public boolean registrarAsociacion(Asociacion As){
        
        //insercion a mysql,preparamos la consulta y realizamos la insercion
        CallableStatement ps=null;
        Connection con = getConexion();
        //INSERT INTO Juega (id_jugador,id_club, temporada ) VALUES(?,?,?)
        
        String sql ="{call ComprobarExisteciaAsociacion(?,?,?)}  ";
        try {
            ps = con.prepareCall(sql);
            ps.setInt(1, As.getId_jugador());
            ps.setInt(2, As.getId_club());
            ps.setInt(3, As.getTemporada());
            ResultSet r=ps.executeQuery();
            String respuesta="";
            while (r.next()){
                respuesta=r.getString(1);
            }
            JOptionPane.showMessageDialog(null, respuesta);
            
            
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(SqlUsuarios.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        
    }
    
       public DefaultTableModel getAsociacionTabla()
    {
      DefaultTableModel tablemodel = new DefaultTableModel();
      int registros = 0;
      String[] columNames = {"Nombre Jugador","Id_Jugador","Nombre equipo","Id_Equipo","Temporada"};//
      //obtenemos la cantidad de registros existentes en la tabla y se almacena en la variable "registros"
      //para formar la matriz de datos
      try{
         PreparedStatement pstm = this.getConexion().prepareStatement( "SELECT count(*) as total FROM Juega");
         ResultSet res = pstm.executeQuery();
         res.next();
         registros = res.getInt("total");
         res.close();
      }catch(SQLException e){
         System.err.println( e.getMessage() );
      }
    //se crea una matriz con tantas filas y columnas que necesite
    Object[][] data = new String[registros][6];
      try{
          //realizamos la consulta sql y llenamos los datos en la matriz "Object[][] data"
         PreparedStatement pstm = this.getConexion().prepareStatement("SELECT * FROM Juega,Jugador,Club WHERE "
                 + "Jugador.id_jugador=Juega.id_Jugador AND Juega.id_club=Club.id_club");
         ResultSet res = pstm.executeQuery();
         int i=0;
         
         while(res.next()){
             
                data[i][0] = res.getString( "Jugador.nombre" );
                data[i][1] = res.getString( "Jugador.id_jugador" );
                data[i][2] = res.getString( "Club.nombre" );
                data[i][3] = res.getString( "Club.id_club" );
                data[i][4] = res.getString( "Juega.temporada");
                
                              
            i++;
         }
         res.close();
         //se añade la matriz de datos en el DefaultTableModel
         tablemodel.setDataVector(data, columNames );
         }catch(SQLException e){
            System.err.println( e.getMessage() );
        }
        return tablemodel;
    }
      public boolean EliminarAsociacion( int id_Jugador,int id_Club )
    {
         boolean res=false;
        //se arma la consulta
        String q = " DELETE FROM Juega WHERE  id_jugador='" + id_Jugador + "'AND id_club='" + id_Club + "' " ;
        //se ejecuta la consulta
         try {
            PreparedStatement pstm = this.getConexion().prepareStatement(q);
            pstm.execute();
            pstm.close();
            res=true;
         }catch(SQLException e){
            System.err.println( e.getMessage() );
        }
        return res;
    }
       public DefaultTableModel BuscarAsociacionJugadores(int id_Jugador)
    {
      DefaultTableModel tablemodel = new DefaultTableModel();
      int registros = 0;
      String[] columNames = {"Nombre Jugador","Id_Jugador","Nombre equipo","Id_Equipo","Temporada"};//
      //obtenemos la cantidad de registros existentes en la tabla y se almacena en la variable "registros"
      //para formar la matriz de datos
      try{
         PreparedStatement pstm = this.getConexion().prepareStatement( "SELECT count(*) as total FROM Juega");
         ResultSet res = pstm.executeQuery();
         res.next();
         registros = res.getInt("total");
         res.close();
      }catch(SQLException e){
         System.err.println( e.getMessage() );
      }
    //se crea una matriz con tantas filas y columnas que necesite
    Object[][] data = new String[registros][6];
      try{
          //realizamos la consulta sql y llenamos los datos en la matriz "Object[][] data"
         PreparedStatement pstm = this.getConexion().prepareStatement("SELECT * FROM Juega,Jugador,Club WHERE "
                 + "Jugador.id_jugador=Juega.id_Jugador AND Juega.id_club=Club.id_club AND Juega.id_Jugador='" + id_Jugador + "' ");
          try (ResultSet res = pstm.executeQuery()) {
              int i=0;
              
              while(res.next()){
                  
                  data[i][0] = res.getString( "Jugador.nombre" );
                  data[i][1] = res.getString( "Jugador.id_jugador" );
                  data[i][2] = res.getString( "Club.nombre" );
                  data[i][3] = res.getString( "Club.id_club" );
                  data[i][4] = res.getString( "Juega.temporada");
                  
                  
                  i++;
              }}
         //se añade la matriz de datos en el DefaultTableModel
         tablemodel.setDataVector(data, columNames );
         }catch(SQLException e){
            System.err.println( e.getMessage() );
        }
        return tablemodel;
    }
       public DefaultTableModel BuscarAsociacionEquipo(int id_club)
    {
      DefaultTableModel tablemodel = new DefaultTableModel();
      int registros = 0;
      String[] columNames = {"Nombre Jugador","Id_Jugador","Nombre equipo","Id_Equipo","Temporada"};//
      //obtenemos la cantidad de registros existentes en la tabla y se almacena en la variable "registros"
      //para formar la matriz de datos
      try{
         PreparedStatement pstm = this.getConexion().prepareStatement( "SELECT count(*) as total FROM Juega");
         ResultSet res = pstm.executeQuery();
         res.next();
         registros = res.getInt("total");
         res.close();
      }catch(SQLException e){
         System.err.println( e.getMessage() );
      } 
    //se crea una matriz con tantas filas y columnas que necesite
    Object[][] data = new String[registros][6];
      try{
          //realizamos la consulta sql y llenamos los datos en la matriz "Object[][] data"
         PreparedStatement pstm = this.getConexion().prepareStatement("SELECT * FROM Juega,Jugador,Club WHERE "
                 + "Jugador.id_jugador=Juega.id_Jugador AND Juega.id_club=Club.id_club AND Juega.id_club='" + id_club + "' ");
          try (ResultSet res = pstm.executeQuery()) {
              int i=0;
              
              while(res.next()){
                  
                  data[i][0] = res.getString( "Jugador.nombre" );
                  data[i][1] = res.getString( "Jugador.id_jugador" );
                  data[i][2] = res.getString( "Club.nombre" );
                  data[i][3] = res.getString( "Club.id_club" );
                  data[i][4] = res.getString( "Juega.temporada");
                  
                  
                  i++;
              }}
         //se añade la matriz de datos en el DefaultTableModel
         tablemodel.setDataVector(data, columNames );
         }catch(SQLException e){
            System.err.println( e.getMessage() );
        }
        return tablemodel;
    }
     
}

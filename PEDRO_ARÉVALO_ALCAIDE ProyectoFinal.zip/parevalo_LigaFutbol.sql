-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost:3306
-- Tiempo de generación: 17-05-2020 a las 14:16:33
-- Versión del servidor: 5.5.65-MariaDB
-- Versión de PHP: 7.3.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `parevalo_LigaFutbol`
--

DELIMITER $$
--
-- Procedimientos
--
CREATE DEFINER=`Pedro`@`%` PROCEDURE `BuscarAsociaXJug` (`id_jug` INT)  SELECT * FROM Juega,Jugador,Club WHERE Jugador.id_jugador=Juega.id_jugador AND Juega.id_club=Club.id_club AND id_jugador=id_jug$$

CREATE DEFINER=`Pedro`@`%` PROCEDURE `ComprobarExisteciaAsociacion` (IN `id_jugador` INT(11), IN `id_equipo` INT(11), IN `Temporada` INT(11))  BEGIN
DECLARE Respuesta VARCHAR(50);
IF EXISTS ( SELECT * FROM Juega WHERE (id_jugador=id_Jugador AND id_equipo=id_club AND temporada=Temporada))
THEN
SET Respuesta ="La asociación ya existe";
SELECT Respuesta AS respuesta;
ELSE
INSERT INTO Juega (id_Jugador ,id_club, temporada) VALUES (id_jugador,id_equipo,temporada);
SET Respuesta ="La asociación ha sido aceptada";
SELECT Respuesta as respuesta;
END IF;
END$$

CREATE DEFINER=`Pedro`@`%` PROCEDURE `GuardaRegistrosJug` (IN `id_jugador` INT(11), IN `id_usuario` INT(11), IN `insertado` DATETIME, IN `NIF` VARCHAR(45), IN `nombreUsuario` VARCHAR(45))  INSERT INTO Reg_Jugadores VALUES(id_jugador,id_usuario,insertado,NIF,nombreUsuario)$$

CREATE DEFINER=`Pedro`@`%` PROCEDURE `MostrarTEquipos` ()  SELECT * FROM Club$$

CREATE DEFINER=`Pedro`@`%` PROCEDURE `MostrarTJugadores` ()  SELECT * FROM Jugador$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Actualiza_Clubs`
--

CREATE TABLE `Actualiza_Clubs` (
  `anterior_añoCreacion` date DEFAULT NULL,
  `anterior_nombre` varchar(100) DEFAULT NULL,
  `anterior_estadios` varchar(100) DEFAULT NULL,
  `nuevo_añoCreacion` date DEFAULT NULL,
  `nuevo_nombre` varchar(100) DEFAULT NULL,
  `nuevo_estadios` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Actualiza_Jugadores`
--

CREATE TABLE `Actualiza_Jugadores` (
  `anterior_nombre` varchar(45) DEFAULT NULL,
  `anterior_apellido` varchar(45) DEFAULT NULL,
  `anterior_nacionalidad` varchar(45) DEFAULT NULL,
  `anterior_fechaNacimiento` date DEFAULT NULL,
  `anterior_NIF` varchar(45) DEFAULT NULL,
  `nuevo_nombre` varchar(45) DEFAULT NULL,
  `nuevo_apellido` varchar(45) DEFAULT NULL,
  `nuevo_nacionalidad` varchar(45) DEFAULT NULL,
  `nuevo_fechaNacimiento` date DEFAULT NULL,
  `nuevo_NIF` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `Actualiza_Jugadores`
--

INSERT INTO `Actualiza_Jugadores` (`anterior_nombre`, `anterior_apellido`, `anterior_nacionalidad`, `anterior_fechaNacimiento`, `anterior_NIF`, `nuevo_nombre`, `nuevo_apellido`, `nuevo_nacionalidad`, `nuevo_fechaNacimiento`, `nuevo_NIF`) VALUES
('Sergio', 'Canales', 'España', '1991-01-16', '12345678L', 'Sergio', 'Canales', 'España', '1991-00-16', '87654321L');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Club`
--

CREATE TABLE `Club` (
  `id_club` int(11) NOT NULL,
  `añoCreacion` date NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `estadios` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `Club`
--

INSERT INTO `Club` (`id_club`, `añoCreacion`, `nombre`, `estadios`) VALUES
(2, '1912-07-01', ' Betis', ' Benito Villamarín'),
(3, '1902-03-06', 'Real Madrid', 'Bernabéu'),
(5, '1902-11-05', ' Barcelona', 'Camp Nou'),
(6, '1980-01-25', 'Sevilla', 'Sanchez Pizjuan'),
(7, '1921-00-23', 'Alavés', 'Mendizorroza'),
(8, '1909-08-07', ' Real Sociedad', ' Reale Arena'),
(9, '1903-03-26', ' Atlético de Madrid', ' Wanda metropolitano'),
(10, '1919-02-19', ' Valencia', ' Mestalla '),
(11, '1931-03-14', ' Granada fc', 'Nuevo los cármenes');

--
-- Disparadores `Club`
--
DELIMITER $$
CREATE TRIGGER `ElimClub` AFTER DELETE ON `Club` FOR EACH ROW INSERT INTO Eliminados_Club (id_Club, añoCreacion,nombre, estadios)
VALUES (old.id_club, old.añoCreacion, old.nombre, old.estadios)
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `memoriaEquipos` BEFORE UPDATE ON `Club` FOR EACH ROW INSERT INTO Actualiza_Clubs (anterior_añoCreacion, anterior_nombre, anterior_estadios,nuevo_añoCreacion, nuevo_nombre, nuevo_estadios)
VALUES(OLD.añoCreacion, OLD.nombre, OLD.estadios, NEW.añoCreacion, NEW.nombre, NEW.estadios)
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Eliminados_Club`
--

CREATE TABLE `Eliminados_Club` (
  `id_Club` int(11) DEFAULT NULL,
  `añoCreacion` date DEFAULT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `estadios` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Eliminados_Juega`
--

CREATE TABLE `Eliminados_Juega` (
  `id_jugador` int(11) DEFAULT NULL,
  `id_club` int(11) DEFAULT NULL,
  `temporada` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Eliminados_Jugadores`
--

CREATE TABLE `Eliminados_Jugadores` (
  `id_jugador` int(11) DEFAULT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `apellido` varchar(100) DEFAULT NULL,
  `nacionalidad` varchar(100) DEFAULT NULL,
  `fechaNacimiento` date DEFAULT NULL,
  `NIF` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Juega`
--

CREATE TABLE `Juega` (
  `id_Jugador` int(11) NOT NULL DEFAULT '0',
  `id_club` int(11) NOT NULL DEFAULT '0',
  `temporada` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `Juega`
--

INSERT INTO `Juega` (`id_Jugador`, `id_club`, `temporada`) VALUES
(1, 6, 1956),
(2, 2, 2020),
(6, 2, 2015),
(6, 3, 1996),
(7, 3, 1996);

--
-- Disparadores `Juega`
--
DELIMITER $$
CREATE TRIGGER `ElimJuega` AFTER DELETE ON `Juega` FOR EACH ROW INSERT INTO Eliminados_Juega (id_jugador, id_club,temporada) VALUES (old.id_Jugador, old.id_club, old.temporada)
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Jugador`
--

CREATE TABLE `Jugador` (
  `id_jugador` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `apellido` varchar(100) NOT NULL,
  `nacionalidad` varchar(100) NOT NULL,
  `fechaNacimiento` date NOT NULL,
  `NIF` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `Jugador`
--

INSERT INTO `Jugador` (`id_jugador`, `nombre`, `apellido`, `nacionalidad`, `fechaNacimiento`, `NIF`) VALUES
(1, 'Jordi', ' Alba', 'España', '1989-03-21', '10948401X'),
(2, 'Nelson', 'Cabral', 'Portugal', '1993-11-16', 'Z8282294E'),
(3, 'Gerald', 'Piqué', 'España', '1987-02-02', '53140087J'),
(6, 'Álvaro', 'Vadillo', 'España', '1994-09-12', '64584378L'),
(7, 'Joaquín', 'Sanchez', 'España', '2020-04-15', '54545409L'),
(9, 'Sergio', 'Canales', 'España', '1991-00-16', '87654321L');

--
-- Disparadores `Jugador`
--
DELIMITER $$
CREATE TRIGGER `ElimJug` AFTER DELETE ON `Jugador` FOR EACH ROW INSERT into Eliminados_Jugadores (id_jugador,nombre,apellido,nacionalidad,fechaNacimiento,NIF)
VALUES(old.id_jugador, old.nombre, old.apellido, old.nacionalidad, old.fechaNacimiento, old.NIF)
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `memoriaJugadores_BU` BEFORE UPDATE ON `Jugador` FOR EACH ROW INSERT INTO Actualiza_Jugadores(
anterior_nombre,anterior_apellido,anterior_nacionalidad,anterior_fechaNacimiento ,anterior_NIF ,nuevo_nombre ,nuevo_apellido ,nuevo_nacionalidad ,nuevo_fechaNacimiento, nuevo_NIF ) VALUES (
OLD.nombre ,OLD.apellido ,OLD.nacionalidad,OLD.fechaNacimiento ,OLD.NIF ,NEW.nombre ,NEW.apellido,NEW.nacionalidad ,NEW.fechaNacimiento , NEW.NIF )
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Operaciones`
--

CREATE TABLE `Operaciones` (
  `id_operacion` int(11) NOT NULL,
  `nombre` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `Operaciones`
--

INSERT INTO `Operaciones` (`id_operacion`, `nombre`) VALUES
(1, 'Ver'),
(2, 'Agregar'),
(3, 'eliminar'),
(4, 'modificar');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `realiza`
--

CREATE TABLE `realiza` (
  `id_tipo` int(11) NOT NULL,
  `id_operacion` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Reg_Jugadores`
--

CREATE TABLE `Reg_Jugadores` (
  `id_jugador` int(11) DEFAULT NULL,
  `NIF` varchar(45) DEFAULT NULL,
  `insertado` datetime DEFAULT NULL,
  `id_usuario` int(11) DEFAULT NULL,
  `nombreUsuario` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Sobre1`
--

CREATE TABLE `Sobre1` (
  `id_operacion` int(11) NOT NULL,
  `id_jugador` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Sobre2`
--

CREATE TABLE `Sobre2` (
  `id_operacion` int(11) NOT NULL,
  `id_club` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo_usuario`
--

CREATE TABLE `tipo_usuario` (
  `id` int(11) NOT NULL,
  `nombre` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `tipo_usuario`
--

INSERT INTO `tipo_usuario` (`id`, `nombre`) VALUES
(1, 'Usuario'),
(2, 'Administrador');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id_usuario` int(11) NOT NULL,
  `usuario` varchar(45) NOT NULL,
  `contraseña` varchar(45) NOT NULL,
  `nombre` varchar(80) NOT NULL,
  `correo` varchar(45) NOT NULL,
  `ultima_sesion` datetime DEFAULT NULL,
  `id_tipo` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id_usuario`, `usuario`, `contraseña`, `nombre`, `correo`, `ultima_sesion`, `id_tipo`) VALUES
(1, 'user1', '1234', 'user1', 'user1@mail.com', NULL, 2),
(2, 'user2', '12345', 'user2', 'user2@mail.com', NULL, 1),
(3, '1', '1', '1', '1@mail.com', '2020-05-15 16:49:43', 1),
(4, 'Pedro', 'pedro', 'pedro', 'pedro@mail.com', '2020-05-17 13:07:12', 2),
(5, 'prueba', '1', 'qw', 'qw@mail.com', NULL, 2),
(6, 'maria', '123', 'mary', 'maria@mail.com', NULL, 2),
(7, 'mario', '123', 'mario', 'mario@mail.com', '2020-05-17 00:52:16', 1),
(8, 'Pepe', 'pepe', 'pepito', 'pepeito@mail.com', NULL, 2),
(9, 'manuel', 'manuel', 'manuel', 'manuel@mail.com', NULL, 2),
(10, 'manolo', 'manolo', 'manolito', 'manolo@mail.com', NULL, 1),
(11, 'prueba3', '1', 'preuba3', 'prueba@mail.com', NULL, 1),
(12, 'prueba4', '2', 'pru', 'prue@mail.com', NULL, 2),
(13, 'preuba34', '11', 'p', 'p@mail.com', NULL, 1),
(14, '123', '123', '123', '123@mail.com', '2020-05-17 01:46:35', 1);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `Club`
--
ALTER TABLE `Club`
  ADD PRIMARY KEY (`id_club`);

--
-- Indices de la tabla `Juega`
--
ALTER TABLE `Juega`
  ADD PRIMARY KEY (`id_Jugador`,`id_club`,`temporada`) USING BTREE,
  ADD KEY `id_club` (`id_club`);

--
-- Indices de la tabla `Jugador`
--
ALTER TABLE `Jugador`
  ADD PRIMARY KEY (`id_jugador`),
  ADD UNIQUE KEY `NIF` (`NIF`);

--
-- Indices de la tabla `Operaciones`
--
ALTER TABLE `Operaciones`
  ADD PRIMARY KEY (`id_operacion`);

--
-- Indices de la tabla `realiza`
--
ALTER TABLE `realiza`
  ADD PRIMARY KEY (`id_tipo`,`id_operacion`),
  ADD KEY `id_operacion` (`id_operacion`);

--
-- Indices de la tabla `Sobre1`
--
ALTER TABLE `Sobre1`
  ADD PRIMARY KEY (`id_operacion`,`id_jugador`),
  ADD KEY `id_jugador` (`id_jugador`);

--
-- Indices de la tabla `Sobre2`
--
ALTER TABLE `Sobre2`
  ADD PRIMARY KEY (`id_operacion`,`id_club`),
  ADD KEY `id_club` (`id_club`);

--
-- Indices de la tabla `tipo_usuario`
--
ALTER TABLE `tipo_usuario`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id_usuario`),
  ADD KEY `id_tipo` (`id_tipo`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `Club`
--
ALTER TABLE `Club`
  MODIFY `id_club` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT de la tabla `Jugador`
--
ALTER TABLE `Jugador`
  MODIFY `id_jugador` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id_usuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `Juega`
--
ALTER TABLE `Juega`
  ADD CONSTRAINT `Juega_ibfk_1` FOREIGN KEY (`id_club`) REFERENCES `Club` (`id_club`),
  ADD CONSTRAINT `Juega_ibfk_2` FOREIGN KEY (`id_Jugador`) REFERENCES `Jugador` (`id_jugador`);

--
-- Filtros para la tabla `realiza`
--
ALTER TABLE `realiza`
  ADD CONSTRAINT `realiza_ibfk_1` FOREIGN KEY (`id_tipo`) REFERENCES `tipo_usuario` (`id`),
  ADD CONSTRAINT `realiza_ibfk_2` FOREIGN KEY (`id_operacion`) REFERENCES `Operaciones` (`id_operacion`);

--
-- Filtros para la tabla `Sobre1`
--
ALTER TABLE `Sobre1`
  ADD CONSTRAINT `Sobre1_ibfk_1` FOREIGN KEY (`id_operacion`) REFERENCES `Operaciones` (`id_operacion`),
  ADD CONSTRAINT `Sobre1_ibfk_2` FOREIGN KEY (`id_jugador`) REFERENCES `Jugador` (`id_jugador`);

--
-- Filtros para la tabla `Sobre2`
--
ALTER TABLE `Sobre2`
  ADD CONSTRAINT `Sobre2_ibfk_1` FOREIGN KEY (`id_operacion`) REFERENCES `Operaciones` (`id_operacion`),
  ADD CONSTRAINT `Sobre2_ibfk_2` FOREIGN KEY (`id_club`) REFERENCES `Club` (`id_club`);

--
-- Filtros para la tabla `tipo_usuario`
--
ALTER TABLE `tipo_usuario`
  ADD CONSTRAINT `tipo_usuario_ibfk_1` FOREIGN KEY (`id`) REFERENCES `usuarios` (`id_tipo`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
